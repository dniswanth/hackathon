package com.klef.jfsd.lms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanManagementSystemProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
